#ifndef MST2_H
#define MST2_H

#include "MatrixGraph.h"
#include "ListGraph.h"

ListGraph Prim(const MatrixGraph &A);

#endif
